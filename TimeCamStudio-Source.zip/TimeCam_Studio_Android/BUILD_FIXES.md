# Native Alpha 0.1.1 — sửa lỗi build #10

Đã xác định từ GitHub Actions build #10:
- `VideoExportEngine.kt:10` import Effects sai package. Sửa thành `androidx.media3.transformer.Effects`.
- `VideoExportEngine.kt:44` CanvasOverlay cần tham số boolean. Sửa thành `CanvasOverlay(true)` để lớp phủ có kích thước video nguồn.
- Các lỗi ở dòng 58 dự kiến được khắc phục sau khi sửa import.
- Tăng versionCode từ 1 lên 2 và versionName thành 0.1.1-native-alpha.

Các thay đổi này chưa được biên dịch và kiểm thử trên máy Android thực trong môi trường tạo tệp. Cần đưa ZIP lên GitHub và chạy Android Actions để xác thực thực tế.
