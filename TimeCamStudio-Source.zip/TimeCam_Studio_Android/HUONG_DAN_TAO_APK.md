# TimeCam Studio – tạo APK không cần Android Studio

**Trạng thái:** Đây là mã nguồn ứng dụng Android beta có cấu hình GitHub Actions để biên dịch APK. **Trong gói ZIP này chưa có file APK**. File APK chỉ có sau khi quy trình build hoàn thành thành công. Việc biên dịch trên GitHub Actions chưa được kiểm chứng từ môi trường tạo gói.

## Cách 1: GitHub Actions (không cần cài Android Studio)

1. Giải nén thư mục `TimeCam_Studio_Android` trong tệp ZIP.
2. Đăng nhập GitHub, tạo một repository mới, chọn **Private** nếu muốn giữ kín mã nguồn.
3. Tải **toàn bộ nội dung bên trong** thư mục `TimeCam_Studio_Android` lên thư mục gốc repository (quan trọng: phải thấy `.github/workflows/build-apk.yml` ở gốc repository).
4. Vào tab **Actions** > **Build TimeCam Studio APK** > **Run workflow**. Nếu workflow tự chạy khi đẩy lên nhánh `main`, đợi chạy xong.
5. Khi workflow chạy thành công, mở trang bản chạy và tải phần **Artifacts** > **TimeCam-Studio-APK**.
6. Giải nén tệp ZIP do GitHub cung cấp; trong đó có `app-debug.apk`.
7. Chép APK vào điện thoại Android 10 trở lên; mở tệp APK để cài, cho phép "Cài ứng dụng không rõ nguồn gốc" đối với ứng dụng mở tệp nếu Android yêu cầu.

Nếu build gặp lỗi, xem log tại tab Actions; đừng cài APK không rõ nguồn. APK `debug` là bản dùng thử, không nên phát hành rộng rãi; bản chính thức cần chữ ký phát hành riêng.

## Cách 2: Android Studio

Mở thư mục dự án, cài SDK Platform 35, sử dụng JDK 17/Gradle 8.9, chọn **Build > Build APK(s)**. Tệp được sinh ra tại `app/build/outputs/apk/debug/app-debug.apk`.

## Lưu ý
- APK chưa được chạy thử trên điện thoại thật.
- Xuất video sử dụng WebM thông qua WebView; tính năng tùy thuộc khả năng hỗ trợ MediaRecorder của phiên bản Android System WebView.
- Đây là ứng dụng thao tác với thông tin thời gian/địa điểm mô phỏng, và lớp phủ sẽ ghi rõ dữ liệu chỉnh sửa.
