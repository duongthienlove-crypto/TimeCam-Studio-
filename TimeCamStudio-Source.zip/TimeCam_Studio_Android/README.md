# TimeCam Studio – Android (bản beta)

Ứng dụng mẫu Android cho việc chụp ảnh, quay video, chọn ảnh/video có sẵn và tạo lớp chữ ngày giờ/địa điểm trực tiếp trên ảnh hoặc video.

## Chức năng hiện có
- Chụp ảnh qua camera và lưu PNG với lớp thông tin.
- Quay video bằng Camera + Micro (khi được cấp quyền), lớp thông tin được vẽ lên từng khung hình; kết quả WebM.
- Chọn ảnh từ thư viện và xuất PNG.
- Chọn video từ thư viện, phát lại và xuất WebM có lớp thông tin. Quá trình chạy theo thời lượng thực của video.
- Ngày giờ hệ thống hoặc ngày giờ tùy chỉnh; khi quay, thời gian chạy tăng liên tục.
- Nhập địa điểm, tọa độ GPS hoặc lấy GPS thực theo quyền của người dùng.
- Đổi vị trí, màu sắc, kích thước chữ và tỷ lệ khung hình.
- Xuất tệp ra **Download/TimeCam Studio**. Không có máy chủ, không đăng nhập.

## Biên dịch thành APK
1. Cài Android Studio gần đây với Android SDK Platform 35, JDK 17 hoặc mới hơn (khuyên JDK 17), Android Gradle Plugin 8.7.3.
2. Mở thư mục gốc `TimeCam_Studio_Android` bằng Android Studio.
3. Chờ Gradle Sync, cài các Android SDK packages được đề nghị.
4. Vào **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Lấy APK debug ở `app/build/outputs/apk/debug/app-debug.apk`, chép vào điện thoại Android 10 trở lên, bật quyền cài đặt ứng dụng từ nguồn này, rồi cài.

Nếu cần tạo Gradle wrapper thủ công, dùng `gradle wrapper --gradle-version 8.9` trên máy có Gradle. Dự án được bàn giao dạng mã nguồn vì môi trường tạo hiện tại **không có Android SDK để trực tiếp biên dịch APK**.

## Yêu cầu và giới hạn
- Khuyên dùng Android 10+ và cập nhật Android System WebView/Chrome.
- Video dùng `MediaRecorder` trên WebView, tùy máy có thể không hỗ trợ. Đây là phiên bản thử nghiệm, **chưa được kiểm thử bằng thiết bị Android thật**.
- Video xuất là WebM, không phải MP4; chưa có 4K, quay nền, camera chuyên sâu, chống rung hay xử lý video tăng tốc bằng phần cứng.
- Xuất video từ thư viện chạy theo thời gian thật; giữ app trước màn hình, không khóa máy. Âm thanh nhập phụ thuộc hỗ trợ của WebView.
- Lớp phủ chỉ hiển thị ngày giờ, địa điểm, GPS và tên nhãn nếu có; không có dòng trạng thái mô phỏng hoặc tùy chỉnh. Đây là dữ liệu có thể nhập thủ công, không xác minh sự kiện ngoài đời.
- Khi chạy file HTML riêng lẻ, chức năng camera thường yêu cầu ngữ cảnh bảo mật `https://` hoặc `localhost`; ảnh/video thư viện vẫn mở được. Trong Android Studio WebView dùng origin HTTPS nội bộ (không kết nối Internet).

## Quyền truy cập
- `CAMERA` – chụp/quay.
- `RECORD_AUDIO` – tiếng trong video.
- `ACCESS_FINE_LOCATION` / `ACCESS_COARSE_LOCATION` – GPS tùy chọn.
- Tệp do người dùng chọn chỉ được đọc qua file chooser; tệp xuất được ghi qua MediaStore.

## Bản demo web
Mở `app/src/main/assets/index.html` bằng Chrome để thử UI và chỉnh sửa ảnh/video từ thư viện. Khi cần dùng camera từ trình duyệt máy tính, chạy qua localhost:
```
cd app/src/main/assets
python3 -m http.server 8080
```
Truy cập `http://localhost:8080`.

## Ghi chú về Gradle wrapper
File `gradle/wrapper/gradle-wrapper.properties` đã được cung cấp để xác định Gradle 8.9, nhưng gói này **không kèm** `gradle-wrapper.jar` và lệnh `gradlew` do máy tạo chưa có Gradle. Dùng Android Studio hoặc Gradle cục bộ để đồng bộ/biên dịch. Nếu muốn chạy từ dòng lệnh, hãy chạy `gradle wrapper --gradle-version 8.9` sau khi đã cài Gradle.
