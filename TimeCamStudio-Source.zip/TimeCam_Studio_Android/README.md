# GPS TIMESTAMP CAMERA PRO — Native Android Alpha v0.1.0

Ứng dụng Android gốc viết bằng Kotlin (không phải WebView) để chụp ảnh, quay video, đọc vị trí GPS, nhập vị trí thủ công và gắn ngày/giờ lên ảnh hoặc video.

**Trạng thái:** dự án nguồn Alpha, chưa biên dịch APK trên môi trường ChatGPT do thiếu Android SDK / Gradle dependency cache. Không coi đây là ứng dụng thương mại hoàn chỉnh.

## Đã lập trình vào mã nguồn

- Giao diện Android native tiếng Việt, nền tối nhấn vàng, 5 mục `CAMERA / VIDEO / THƯ VIỆN / MẪU / CÀI ĐẶT`, bảng công cụ có thể thu gọn.
- CameraX: camera trước/sau, chụp ảnh JPEG từ camera và đóng dấu vào bản PNG mới, ghi MP4 tạm bằng CameraX `Recorder` rồi dùng xuất MP4 với lớp thông tin.
- GPS thực tế bằng `LocationManager` và geocoding thiết bị khi dịch vụ khả dụng, yêu cầu quyền riêng biệt. Nhập tọa độ/địa chỉ tùy chỉnh, xác thực giới hạn kinh/vĩ độ, lưu nguồn GPS vs thủ công.
- Lớp phủ Canvas dùng chung cho ảnh, xem trước và video; đổi cỡ 50%–250%, độ trong suốt, màu, chọn kiểu và kéo di chuyển trên hình.
- Mở ảnh/video qua Android OpenDocument; `VideoView` tua/pause; mặc định xuất toàn video; tùy chọn cắt theo giây.
- Media3 Transformer + CanvasOverlay: theo presentation timestamp từng khung hình; đổ timestamp vào MP4 H.264/AAC; giữ audio (`removeAudio=false`), kiểm tra thời lượng + kênh audio khi xuất; chỉ đưa video thành phẩm hợp lệ vào MediaStore `Movies/GPS Timestamp Camera Pro`.
- Không làm thay đổi file gốc. Tự lưu cài đặt qua SharedPreferences; chia sẻ file thành phẩm bằng Android Share Sheet.
- 10 tên mẫu dùng chung renderer, đang ở giai đoạn tinh chỉnh bố cục.

## Chưa đạt và cần kiểm thử/thực hiện tiếp

- Chưa build/kiểm thử APK thực tế trên thiết bị. Media3 renderer có thể cần điều chỉnh theo kết quả CI/thiết bị.
- Chưa triển khai Jetpack Compose; hiện dùng Android Views native để ưu tiên hoàn thiện chức năng xử lý thật.
- Chưa có bản đồ chọn điểm GPS, lưu nhiều preset GPS, CameraX tap-focus/flash/zoom, chuyển video tốc độ phát, kéo từng dòng riêng, nhập ngày từ metadata EXIF/video, ảnh JPEG xuất trực tiếp, H.265/4K/2K cấu hình, khả năng phát lại kiểm định 10 phút, đồng bộ dự án nhiều phiên bản.
- Chưa có bộ kiểm thử tích hợp Media3 2 phút 07 giây + video 10 phút trên điện thoại, chưa xác nhận giữ âm thanh trong các codec lạ.
- Bộ tên 10 mẫu có sự khác nhau ở một số kiểu nhấn mạnh; vẫn cần hoàn thiện để đủ 10 thiết kế khác biệt hoàn toàn.
- Ngày/giờ và tọa độ nhập thủ công chỉ là *văn bản được chèn*, không phải chứng cứ xác thực. Trạng thái nguồn chỉnh sửa được giữ trong cài đặt, nhưng chưa có tính năng xuất lịch sử kiểm toán riêng.
- Hiện dùng applicationId riêng `vn.skyline.gpstimestamp` nên cài song song với TimeCam Studio cũ, không ghi đè ứng dụng cũ.

## Build thủ công

Dự án yêu cầu Java 17, Android SDK Platform 35, Android Gradle Plugin 8.7.3, Gradle 8.9, Kotlin 2.0.21.

```bash
gradle --no-daemon testDebugUnitTest assembleDebug
```

APK nếu build thành công: `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions

File `.github/workflows/build-apk.yml` sẽ chạy test + build rồi đính APK dưới mục **Artifacts**. Nếu chạy workflow thất bại, hãy gửi logs; không được giả định APK tồn tại khi job chưa xanh.

## Kiến trúc

- `MainActivity.kt`: UI native / camera lifecycle / picker / các điều khiển.
- `TimeEngine.kt`: xử lý thời gian xuất chuẩn theo microseconds timestamp.
- `StampModel.kt`: cấu hình và nguồn nhập GPS/time.
- `StampRenderer.kt`: vẽ lớp phủ ảnh/video.
- `StampOverlayView.kt`: xem trước, drag vị trí.
- `LocationRepository.kt`: GPS thiết bị / địa chỉ.
- `PhotoEngine.kt`: xử lý PNG thật.
- `VideoExportEngine.kt`: xuất MP4 với Media3 Transformer và validate âm thanh/duration.
- `MediaStoreUtils.kt`: kiểm tra track / publish MediaStore.
- `ProjectStore.kt`: lưu cấu hình cục bộ.

## Cập nhật trên repository hiện có

Repository trước của người dùng có workflow `.github/workflows/build-apk-from-zip.yml` đang giải nén `TimeCamStudio-Source.zip` vào `source/TimeCam_Studio_Android` và chạy `gradle assembleDebug`. File ZIP tương thích tên `TimeCamStudio-Source.zip` đi kèm cung cấp thư mục `TimeCam_Studio_Android/` (chính là mã nguồn dự án này). Sau khi thay ZIP cũ, workflow sẽ build app mới bằng cùng câu lệnh. Ứng dụng mới có package riêng và sẽ cài cạnh app cũ.

**Quan trọng:** mã nguồn này có cấu trúc/kiến trúc khác dự án TimeCam Studio cũ; không nên giới thiệu là phiên bản cập nhật đã kiểm thử của app cũ trước khi CI & thiết bị xác nhận thành công.
