# Báo cáo kiểm thử — v0.1.0 Native Alpha

## Thực hiện trong môi trường ChatGPT

- `kotlinc app/src/main/java/vn/skyline/gpstimestamp/TimeEngine.kt tools/TimeEngineTest.kt -include-runtime -d /tmp/timeengine_test.jar` — PASS.
- `java -jar /tmp/timeengine_test.jar` — PASS 9 checks: 00:00, 00:15, 05:00, 10:00, 02:07, clipping, full range, custom range, invalid range.
- Đã tạo workflow GitHub Actions với build `testDebugUnitTest assembleDebug`.
- Chưa thể chạy Android Gradle Plugin hoặc Media3/CameraX tại đây vì không có Android SDK, không có kết nối tải từ Google Maven.

## BẮT BUỘC kiểm tra bằng thiết bị sau khi build

1. Lấy GPS thực, kiểm tra `±meters` và chuyển sang nhập tọa độ thủ công.
2. Chụp và xuất PNG, xác minh lớp chữ nằm đúng vị trí/cỡ chữ.
3. Video dài 02:07, đặt 08:30:00, xác minh 08:30:45 / 08:32:07.
4. Xuất đầy đủ 02:07, không tự cắt, audio input và output có track.
5. Video dài >= 10 phút, so sánh thời lượng và A/V sync.
6. Camera trước/sau, ghi âm và quyền trên Android 10–15.
7. Thử video dọc/ngang, 720p/1080p, nhiều codec.
8. Cài song song với TimeCam Studio và phát lại file MP4 đã lưu.

Không tuyên bố những bài kiểm tra thiết bị đã chạy nếu chưa có logs/video chứng minh.
