package vn.skyline.gpstimestamp

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.CancellationSignal
import java.util.Locale

class LocationRepository(private val context: Context) {
    fun requestCurrentLocation(onResult: (Location?, String?) -> Unit) {
        val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            onResult(null, "Bạn chưa cấp quyền vị trí"); return
        }
        val hasFine = context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val candidates = if (hasFine)
            listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
        else listOf(LocationManager.NETWORK_PROVIDER)
        val providers = candidates.filter { runCatching { manager.isProviderEnabled(it) }.getOrDefault(false) }
        if (providers.isEmpty()) { onResult(null, "Không bật GPS hoặc dịch vụ định vị"); return }
        if (Build.VERSION.SDK_INT < 30) {
            val location = providers.mapNotNull { runCatching { manager.getLastKnownLocation(it) }.getOrNull() }
                .maxByOrNull { it.time }
            onResult(location, if (location == null) "Không đọc được vị trí trên Android 10" else "Vị trí thiết bị đã lưu gần nhất")
            return
        }
        runCatching {
            manager.getCurrentLocation(providers.first(), CancellationSignal(), context.mainExecutor) { location ->
                if (location != null) onResult(location, null) else {
                    val fallback = providers.mapNotNull { runCatching { manager.getLastKnownLocation(it) }.getOrNull() }
                        .maxByOrNull { it.time }
                    onResult(fallback, if (fallback == null) "Không lấy được tọa độ" else "Dùng vị trí gần nhất của thiết bị")
                }
            }
        }.onFailure { onResult(null, it.message ?: "GPS không khả dụng") }
    }
    fun addressFor(location: Location, callback: (String) -> Unit) {
        if (!Geocoder.isPresent()) { callback(""); return }
        val geocoder = Geocoder(context, Locale("vi", "VN"))
        if (Build.VERSION.SDK_INT >= 33) {
            geocoder.getFromLocation(location.latitude, location.longitude, 1,
                object : Geocoder.GeocodeListener {
                    override fun onGeocode(addresses: MutableList<android.location.Address>) {
                        callback(addresses.firstOrNull()?.getAddressLine(0) ?: "")
                    }
                    override fun onError(errorMessage: String?) { callback("") }
                })
        } else {
            Thread {
                @Suppress("DEPRECATION")
                val address = runCatching { geocoder.getFromLocation(location.latitude, location.longitude, 1)
                    ?.firstOrNull()?.getAddressLine(0) }.getOrNull() ?: ""
                (context as android.app.Activity).runOnUiThread { callback(address) }
            }.start()
        }
    }
}
