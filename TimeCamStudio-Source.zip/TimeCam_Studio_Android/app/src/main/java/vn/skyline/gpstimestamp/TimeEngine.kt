package vn.skyline.gpstimestamp

/** Pure Kotlin: the clock is a function of media presentation time, NOT wall-clock time. */
object TimeEngine {
    /** At source timestamp `sourcePositionUs`, display epoch `startEpochMs + sourcePositionUs / 1000`. */
    fun atPresentationUs(startEpochMs: Long, sourcePositionUs: Long): Long =
        startEpochMs + sourcePositionUs.coerceAtLeast(0L) / 1_000L

    /** A clipped video begins at source time `trimStartMs`, not at an artificial zero. */
    fun atClippedPresentationUs(startEpochMs: Long, trimStartMs: Long, presentationTimeUs: Long): Long =
        startEpochMs + trimStartMs.coerceAtLeast(0L) + presentationTimeUs.coerceAtLeast(0L) / 1_000L

    fun validateRange(durationMs: Long, startMs: Long, endMs: Long, cut: Boolean): Pair<Long, Long> {
        require(durationMs > 0L) { "Video duration must be positive" }
        if (!cut) return 0L to durationMs
        require(startMs in 0 until durationMs && endMs in 1..durationMs && endMs > startMs) { "Invalid trim range" }
        return startMs to endMs
    }
}
