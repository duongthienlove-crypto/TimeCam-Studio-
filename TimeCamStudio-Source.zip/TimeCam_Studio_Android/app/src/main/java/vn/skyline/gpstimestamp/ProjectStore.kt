package vn.skyline.gpstimestamp

import android.content.Context
import org.json.JSONObject

/** Lightweight autosave; user-entered GPS does not override original media metadata. */
class ProjectStore(context: Context) {
    private val prefs = context.getSharedPreferences("project", Context.MODE_PRIVATE)
    fun save(m: StampModel) {
        val o = JSONObject()
            .put("manual", m.manualGps).put("address", m.address)
            .put("lat", m.latitude ?: JSONObject.NULL).put("lon", m.longitude ?: JSONObject.NULL)
            .put("scale", m.scale.toDouble()).put("alpha", m.alpha.toDouble())
            .put("x", m.x.toDouble()).put("y", m.y.toDouble())
            .put("template", m.template).put("color", m.textColor).put("note", m.note)
            .put("custom", m.customTime).put("time", m.startEpochMs)
        prefs.edit().putString("settings", o.toString()).apply()
    }
    fun load(): StampModel {
        val o = runCatching { JSONObject(prefs.getString("settings", "{}") ?: "{}") }
            .getOrElse { JSONObject() }
        fun numeric(k: String): Double? = if (o.isNull(k)) null else o.optDouble(k).takeIf { !it.isNaN() }
        return StampModel(
            manualGps = o.optBoolean("manual", true),
            address = o.optString("address", "Hà Tĩnh, Việt Nam"),
            latitude = numeric("lat"), longitude = numeric("lon"),
            scale = o.optDouble("scale", 1.0).toFloat(),
            alpha = o.optDouble("alpha", 1.0).toFloat(),
            x = o.optDouble("x", .035).toFloat(), y = o.optDouble("y", .84).toFloat(),
            template = o.optInt("template", 0), textColor = o.optInt("color", android.graphics.Color.WHITE),
            note = o.optString("note", ""), customTime = o.optBoolean("custom", false),
            startEpochMs = o.optLong("time", System.currentTimeMillis())
        )
    }
}
