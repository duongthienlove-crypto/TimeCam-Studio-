package vn.skyline.gpstimestamp

import kotlin.math.floor

/** Geometry only: preserves source aspect ratio, without cropping or stretching. */
object FrameGeometry {
    data class Size(val width: Int, val height: Int)

    fun fitInside(availableWidth: Int, availableHeight: Int, aspect: Double): Size {
        require(availableWidth > 0 && availableHeight > 0) { "Invalid viewport" }
        require(aspect.isFinite() && aspect > 0.0) { "Invalid aspect ratio" }
        val width = minOf(availableWidth.toDouble(), availableHeight.toDouble() * aspect)
        val height = width / aspect
        // Floor both axes so content never exceeds parent, including unusual aspect ratios.
        return Size(floor(width).toInt().coerceAtLeast(1),
            floor(height).toInt().coerceAtLeast(1))
    }
}
