package vn.skyline.gpstimestamp

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.net.Uri
import java.io.File

class PhotoEngine(private val context: Context) {
    fun export(source: Uri, model: StampModel, epochMs: Long): Uri {
        val decoder = ImageDecoder.createSource(context.contentResolver, source)
        val original = ImageDecoder.decodeBitmap(decoder) { options, info, _ ->
            options.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val max = info.size.width.coerceAtLeast(info.size.height)
            if (max > 4096) options.setTargetSampleSize((max / 4096).coerceAtLeast(1))
        }
        val mutable = original.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(mutable)
        StampRenderer.draw(canvas, mutable.width, mutable.height, model, epochMs)
        val temp = File(context.cacheDir, "photo_${System.currentTimeMillis()}.png")
        temp.outputStream().use { output ->
            check(mutable.compress(Bitmap.CompressFormat.PNG, 100, output)) { "Không mã hóa được ảnh" }
        }
        val uri = MediaStoreUtils.publish(context, temp,
            "GPS_Timestamp_${System.currentTimeMillis()}.png", "image/png")
        temp.delete(); mutable.recycle(); original.recycle()
        return uri
    }
}
