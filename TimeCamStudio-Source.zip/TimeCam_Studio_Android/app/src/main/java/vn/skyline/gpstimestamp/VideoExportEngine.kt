package vn.skyline.gpstimestamp

import android.content.Context
import android.graphics.Canvas
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.transformer.Effects
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.CanvasOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File

/** Media3 Transformer transcodes actual frames and keeps source audio enabled. */
@OptIn(UnstableApi::class)
class VideoExportEngine(private val context: Context) {
    private var current: Transformer? = null
    private var output: File? = null
    private val handler = Handler(Looper.getMainLooper())
    private var tick: Runnable? = null

    fun export(input: Uri, stamp: StampModel, useCustomRange: Boolean = false,
               fromMs: Long = 0L, toMs: Long = 0L,
               status: (String) -> Unit, completed: (Result<Uri>) -> Unit) {
        if (current != null) { completed(Result.failure(IllegalStateException("Đã có tác vụ xuất đang chạy"))); return }
        val originalDuration = runCatching { MediaStoreUtils.durationMs(context, input) }.getOrDefault(0L)
        if (originalDuration <= 0L) { completed(Result.failure(IllegalArgumentException("Không đọc được thời lượng video"))); return }
        val range = runCatching { TimeEngine.validateRange(originalDuration, fromMs, toMs, useCustomRange) }
            .getOrElse { completed(Result.failure(it)); return }
        val sourceHasAudio = runCatching { MediaStoreUtils.hasAudio(context, input) }.getOrDefault(false)
        val temp = File(context.cacheDir, "export_${System.currentTimeMillis()}.mp4")
        output = temp
        val config = stamp.copy()
        val effect = object : CanvasOverlay(true) {
            override fun onDraw(canvas: Canvas, presentationTimeUs: Long) {
                val clockMs = if (config.customTime)
                    TimeEngine.atClippedPresentationUs(config.startEpochMs, range.first, presentationTimeUs)
                else System.currentTimeMillis() // Non-custom mode: live time; not used for historical verification
                StampRenderer.draw(canvas, canvas.width, canvas.height, config, clockMs)
            }
        }
        val media = MediaItem.Builder().setUri(input).apply {
            if (useCustomRange) setClippingConfiguration(MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(range.first).setEndPositionMs(range.second).build())
        }.build()
        val edited = EditedMediaItem.Builder(media)
            .setRemoveAudio(false)
            .setEffects(Effects(emptyList(), listOf<Effect>(OverlayEffect(listOf(effect)))))
            .build()
        val transformer = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    cancelProgress()
                    current = null
                    try {
                        val actual = MediaStoreUtils.durationMs(temp)
                        val expected = range.second - range.first
                        if (kotlin.math.abs(actual - expected) > 1_500L) {
                            throw IllegalStateException("Video bị lệch thời lượng: mong đợi $expected ms, xuất $actual ms")
                        }
                        if (sourceHasAudio && !MediaStoreUtils.hasAudio(temp)) {
                            throw IllegalStateException("Video đầu ra bị mất âm thanh")
                        }
                        val saved = MediaStoreUtils.publish(context, temp,
                            "GPS_Timestamp_${System.currentTimeMillis()}.mp4", "video/mp4")
                        temp.delete()
                        status("Đã lưu MP4 đầy đủ vào Movies/GPS Timestamp Camera Pro")
                        completed(Result.success(saved))
                    } catch (e: Exception) { temp.delete(); completed(Result.failure(e)) }
                }
                override fun onError(composition: Composition, exportResult: ExportResult,
                                     exportException: ExportException) {
                    cancelProgress(); current = null; temp.delete()
                    completed(Result.failure(exportException))
                }
            }).build()
        try {
            current = transformer
            status("Đang tạo video MP4 có timestamp…")
            transformer.start(edited, temp.absolutePath)
            val monitor = object : Runnable {
                override fun run() {
                    if (current !== transformer) return
                    val holder = ProgressHolder()
                    val state = transformer.getProgress(holder)
                    if (state == Transformer.PROGRESS_STATE_AVAILABLE) status("Đang xuất: ${holder.progress}%")
                    handler.postDelayed(this, 500)
                }
            }
            tick = monitor
            handler.post(monitor)
        } catch (e: Exception) {
            current = null; cancelProgress(); temp.delete(); completed(Result.failure(e))
        }
    }
    fun cancel() {
        current?.cancel(); current = null; cancelProgress(); output?.delete()
    }
    private fun cancelProgress() { tick?.let { handler.removeCallbacks(it) }; tick = null }
}
