package vn.skyline.gpstimestamp

data class StampModel(
    val customTime: Boolean = false,
    val startEpochMs: Long = System.currentTimeMillis(),
    val manualGps: Boolean = true,
    val address: String = "Hà Tĩnh, Việt Nam",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val gpsAccuracy: Float? = null,
    val scale: Float = 1f,
    val alpha: Float = 1f,
    val x: Float = .035f,
    val y: Float = .84f,
    val template: Int = 0,
    val textColor: Int = android.graphics.Color.WHITE,
    val note: String = ""
) {
    fun isLocationValid(): Boolean = latitude != null && longitude != null &&
        latitude in -90.0..90.0 && longitude in -180.0..180.0
    fun locationLabel(): String = when {
        isLocationValid() -> "GPS: %.6f, %.6f".format(java.util.Locale.US, latitude, longitude)
        else -> ""
    }
    fun locationOrigin(): String = if (manualGps) "Nhập thủ công" else "GPS thiết bị"
}
