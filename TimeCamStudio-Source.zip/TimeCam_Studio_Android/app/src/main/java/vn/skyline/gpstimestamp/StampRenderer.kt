package vn.skyline.gpstimestamp

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Same renderer for preview, photographs, and every decoded export frame. */
object StampRenderer {
    val templateNames = listOf(
        "Timestamp Classic", "Professional", "GPS Minimal", "Business Travel", "Construction",
        "Travel Memories", "Cinematic", "Digital Clock", "Location Information", "Custom"
    )
    fun draw(canvas: Canvas, width: Int, height: Int, stamp: StampModel, epochMs: Long) {
        if (width <= 0 || height <= 0) return
        val date = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale("vi", "VN")).format(Date(epochMs))
        val latitude = stamp.locationLabel()
        val data = mutableListOf(date)
        if (stamp.address.isNotBlank()) data += stamp.address.trim()
        if (latitude.isNotEmpty()) data += latitude
        if (stamp.note.isNotBlank()) data += stamp.note.trim()
        if (data.isEmpty()) return
        val base = height.coerceAtMost(width) / 26f
        val size = (base * stamp.scale).coerceAtLeast(11f)
        val padding = size * .52f
        val gap = size * .34f
        val lineHeight = size * 1.32f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = stamp.textColor
            textSize = size
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            alpha = (stamp.alpha * 255).toInt().coerceIn(0, 255)
            setShadowLayer(size * .12f, 0f, 2f, Color.BLACK)
        }
        val maxWidth = width * .90f
        val output = data.flatMap { wordWrap(it, paint, maxWidth - padding * 2) }
        if (output.isEmpty()) return
        val blockW = (output.maxOf { paint.measureText(it) } + padding * 2).coerceAtMost(maxWidth)
        val blockH = output.size * lineHeight + padding * 1.25f
        val originX = (stamp.x * width).coerceIn(0f, (width - blockW).coerceAtLeast(0f))
        val originY = (stamp.y * height).coerceIn(0f, (height - blockH).coerceAtLeast(0f))
        canvas.save()
        val template = stamp.template.coerceIn(0, templateNames.size - 1)
        if (template in listOf(1, 3, 4, 7, 8, 9)) {
            val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(if (template == 7) 220 else 145, 7, 13, 20)
            }
            canvas.drawRoundRect(RectF(originX, originY, originX + blockW, originY + blockH),
                size * .26f, size * .26f, fill)
        }
        if (template in listOf(1, 4, 8)) {
            val accent = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(228, 182, 101) }
            canvas.drawRoundRect(RectF(originX, originY, originX + size * .12f, originY + blockH),
                size * .04f, size * .04f, accent)
        }
        if (template == 5) paint.typeface = android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.ITALIC)
        if (template == 6) paint.typeface = android.graphics.Typeface.create("sans-serif-condensed-light", android.graphics.Typeface.NORMAL)
        if (template == 7) paint.typeface = android.graphics.Typeface.MONOSPACE
        if (template == 3) {
            val accent = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(242, 208, 147) }
            canvas.drawRect(originX, originY, originX + blockW, originY + size * .11f, accent)
        }
        if (template == 9) {
            val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = 1.4f; color = Color.rgb(163, 189, 198)
            }
            canvas.drawRoundRect(RectF(originX, originY, originX + blockW, originY + blockH), 4f, 4f, frame)
        }
        output.forEachIndexed { i, line ->
            if (template == 2 && i == 0) paint.color = Color.rgb(242, 206, 129)
            else paint.color = stamp.textColor
            val left = originX + padding
            val top = originY + padding + size + i * lineHeight
            canvas.drawText(line, left, top, paint)
        }
        canvas.restore()
    }
    private fun wordWrap(value: String, paint: Paint, maxWidth: Float): List<String> {
        val lines = ArrayList<String>()
        var current = ""
        for (word in value.split(Regex("\\s+"))) {
            val next = if (current.isEmpty()) word else "$current $word"
            if (current.isNotEmpty() && paint.measureText(next) > maxWidth) {
                lines += current
                current = word
            } else current = next
        }
        if (current.isNotEmpty()) lines += current
        return lines
    }
}
