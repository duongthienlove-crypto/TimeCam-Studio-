package vn.skyline.gpstimestamp

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.AspectRatio
import androidx.camera.core.UseCaseGroup
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Android-native UI. Images are rendered with Canvas; MP4 video via Media3 Transformer. */
class MainActivity : ComponentActivity() {
    private val ink = Color.rgb(13, 18, 26)
    private val panel = Color.rgb(23, 31, 42)
    private val gold = Color.rgb(231, 189, 118)
    private val white = Color.rgb(244, 246, 249)
    private val muted = Color.rgb(168, 179, 193)
    private var model = StampModel()
    private lateinit var saved: ProjectStore
    private lateinit var location: LocationRepository
    private lateinit var exporter: VideoExportEngine
    private lateinit var preview: PreviewView
    private lateinit var stage: FrameLayout
    private lateinit var contentStage: FrameLayout
    private lateinit var ratioSelect: Spinner
    private var mediaWidth: Int = 0
    private var mediaHeight: Int = 0
    private lateinit var overlay: StampOverlayView
    private lateinit var player: VideoView
    private lateinit var imagePreview: ImageView
    private lateinit var actions: LinearLayout
    private lateinit var status: TextView
    private lateinit var timeline: SeekBar
    private lateinit var counter: TextView
    private lateinit var dateButton: Button
    private lateinit var customTimeCheck: CheckBox
    private lateinit var addressInput: EditText
    private lateinit var latitudeInput: EditText
    private lateinit var longitudeInput: EditText
    private lateinit var noteInput: EditText
    private lateinit var trimToggle: CheckBox
    private lateinit var trimFrom: EditText
    private lateinit var trimTo: EditText
    private lateinit var locationMode: Spinner
    private lateinit var settingsPanel: LinearLayout
    private lateinit var cameraAction: Button
    private lateinit var recordAction: Button
    private lateinit var exportAction: Button
    private lateinit var shareAction: Button
    private lateinit var switchAction: Button
    private var activeTab = "CAMERA"
    private var usingFrontCamera = false
    private var cameraProvider: ProcessCameraProvider? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var recordStartElapsedMs: Long = 0L
    private var selectedMedia: Uri? = null
    private var selectedIsVideo = false
    private var mediaDurationMs = 0L
    private var lastExport: Uri? = null
    private val taskRunner: ExecutorService = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private val clockFormat = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale("vi", "VN"))

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            loadMedia(uri)
        }
    }
    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result[Manifest.permission.CAMERA] == true) startCamera()
        if (result[Manifest.permission.ACCESS_FINE_LOCATION] == true || result[Manifest.permission.ACCESS_COARSE_LOCATION] == true) refreshGps()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        saved = ProjectStore(this); model = saved.load()
        location = LocationRepository(this); exporter = VideoExportEngine(this)
        buildUi()
        setTab("CAMERA")
        uiClock()
    }
    override fun onDestroy() {
        super.onDestroy()
        if (recording != null) recording?.stop()
        exporter.cancel(); taskRunner.shutdownNow(); handler.removeCallbacksAndMessages(null)
    }
    private fun dp(value: Int): Int = (resources.displayMetrics.density * value).toInt()
    private fun column(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun row(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun label(value: String, size: Float = 13f, color: Int = muted): TextView = TextView(this).apply {
        text = value; setTextColor(color); textSize = size
        setPadding(0, dp(5), 0, dp(5))
    }
    private fun button(value: String, prominent: Boolean = false): Button = Button(this).apply {
        text = value; textSize = 12f; isAllCaps = false
        setTextColor(if (prominent) ink else white)
        backgroundTintList = android.content.res.ColorStateList.valueOf(if (prominent) gold else panel)
        minHeight = dp(46)
    }
    private fun entry(value: String = "", hintText: String = ""): EditText = EditText(this).apply {
        setSingleLine(true); setText(value); hint = hintText; textSize = 14f
        setTextColor(white); setHintTextColor(muted); backgroundTintList = android.content.res.ColorStateList.valueOf(gold)
    }
    private fun LinearLayout.addFull(view: View, top: Int = 3) {
        val params = LinearLayout.LayoutParams(-1, -2); params.topMargin = dp(top)
        addView(view, params)
    }
    private fun LinearLayout.addWeighted(view: View, weight: Float = 1f) {
        addView(view, LinearLayout.LayoutParams(0, -2, weight))
    }
    private fun separator(): View = View(this).apply {
        setBackgroundColor(Color.rgb(49, 61, 77)); layoutParams = LinearLayout.LayoutParams(-1, dp(1))
    }
    private fun buildUi() {
        val root = column().apply { setBackgroundColor(ink) }
        setContentView(root)
        val heading = label("◈  GPS TIMESTAMP  CAMERA PRO", 19f, gold).apply {
            typeface = Typeface.DEFAULT_BOLD; setPadding(dp(16), dp(16), dp(16), dp(7))
        }
        root.addView(heading)
        val bar = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val tabs = row()
        for (tab in listOf("CAMERA", "VIDEO", "THƯ VIỆN", "MẪU", "CÀI ĐẶT")) {
            val btn = button(tab)
            tabs.addView(btn, LinearLayout.LayoutParams(dp(108), dp(46)))
            btn.setOnClickListener { if (tab == "THƯ VIỆN") picker.launch(arrayOf("image/*", "video/*")) else setTab(tab) }
        }
        bar.addView(tabs); root.addView(bar)
        stage = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(stage, LinearLayout.LayoutParams(-1, 0, 1f))
        contentStage = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        stage.addView(contentStage, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        stage.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> fitContentFrame() }
        preview = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FIT_CENTER
        }
        player = VideoView(this)
        imagePreview = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        overlay = StampOverlayView(this).apply {
            stamp = model
            dragListener = { x, y ->
                model = model.copy(x = x.coerceIn(0f, 1f), y = y.coerceIn(0f, 1f))
                updateStamp(); info("Đã di chuyển dấu thời gian")
            }
        }
        for (view in listOf(preview, player, imagePreview, overlay)) {
            contentStage.addView(view, FrameLayout.LayoutParams(-1, -1))
        }
        val bottom = column().apply { setPadding(dp(13), dp(4), dp(13), dp(8)) }
        root.addView(bottom)
        val transport = row()
        val togglePlay = button("▶ / ❚❚")
        togglePlay.setOnClickListener { if (player.isPlaying) player.pause() else if (selectedIsVideo) player.start() }
        transport.addView(togglePlay, LinearLayout.LayoutParams(dp(82), dp(44)))
        timeline = SeekBar(this).apply { max = 1000 }
        transport.addView(timeline, LinearLayout.LayoutParams(0, -2, 1f))
        counter = label("00:00 / 00:00", 11f)
        transport.addView(counter)
        bottom.addFull(transport)
        timeline.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser && mediaDurationMs > 0) player.seekTo((progress / 1000.0 * mediaDurationMs).toInt())
            }
        })
        actions = row(); bottom.addFull(actions)
        cameraAction = button("◉ CHỤP ẢNH", true).apply { setOnClickListener { takePhoto() } }
        recordAction = button("● QUAY VIDEO", true).apply { setOnClickListener { toggleRecording() } }
        switchAction = button("⇄ ĐỔI CAMERA").apply {
            setOnClickListener {
                if (recording != null) info("Dừng quay trước khi đổi camera")
                else { usingFrontCamera = !usingFrontCamera; startCamera() }
            }
        }
        exportAction = button("↓ LƯU ẢNH / VIDEO", true).apply { setOnClickListener { exportSelected() } }
        shareAction = button("↗ CHIA SẺ").apply { setOnClickListener { shareExport() } }
        for (b in listOf(cameraAction, recordAction, switchAction, exportAction, shareAction)) {
            actions.addWeighted(b)
        }
        status = label("Sẵn sàng", 12f)
        bottom.addFull(status)
        val settingsToggle = button("⌄  BẢNG ĐIỀU KHIỂN / THU GỌN")
        root.addView(settingsToggle, LinearLayout.LayoutParams(-1, dp(42)))
        val scroll = ScrollView(this)
        root.addView(scroll, LinearLayout.LayoutParams(-1, dp(284)))
        scroll.visibility = View.GONE // Full-height portrait camera preview on first launch.
        settingsToggle.setOnClickListener {
            scroll.visibility = if (scroll.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        settingsPanel = column().apply { setPadding(dp(17), dp(12), dp(17), dp(30)); setBackgroundColor(panel) }
        scroll.addView(settingsPanel)
        settingsPanel.addFull(label("KHUNG HÌNH · DỌC THÔNG MINH", 14f, gold))
        ratioSelect = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Dọc 9:16 (mặc định)", "Dọc 3:4", "Dọc toàn màn hình", "Vuông 1:1"))
        }
        settingsPanel.addFull(ratioSelect)
        ratioSelect.setSelection(getPreferences(MODE_PRIVATE).getInt("camera_ratio", 0).coerceIn(0, 3))
        ratioSelect.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, index: Int, id: Long) {
                if (recording != null) { info("Không đổi tỷ lệ khi đang ghi hình"); return }
                getPreferences(MODE_PRIVATE).edit().putInt("camera_ratio", index).apply()
                fitContentFrame()
                if (activeTab == "CAMERA" || activeTab == "VIDEO") startCamera()
            }
        }
        settingsPanel.addFull(label("Máy ảnh ưu tiên khung dọc. Ảnh/video thư viện tự hiển thị nguyên tỷ lệ gốc, không kéo giãn hoặc cắt hình."))
        settingsPanel.addFull(separator(), 12)
        settingsPanel.addFull(label("01   THỜI GIAN HIỂN THỊ", 14f, gold))
        val timeRow = row()
        customTimeCheck = CheckBox(this).apply { text = "Tùy chỉnh giờ bắt đầu"; setTextColor(white); isChecked = model.customTime }
        timeRow.addWeighted(customTimeCheck)
        dateButton = button(clockFormat.format(Date(model.startEpochMs)))
        timeRow.addWeighted(dateButton)
        settingsPanel.addFull(timeRow)
        customTimeCheck.setOnCheckedChangeListener { _, checked -> model = model.copy(customTime = checked); updateStamp() }
        dateButton.setOnClickListener { pickDateTime() }
        settingsPanel.addFull(separator(), 12)
        settingsPanel.addFull(label("02   VỊ TRÍ / GPS", 14f, gold))
        locationMode = Spinner(this)
        locationMode.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Nhập thủ công", "GPS thực tế của thiết bị"))
        locationMode.setSelection(if (model.manualGps) 0 else 1)
        settingsPanel.addFull(locationMode)
        val refresh = button("⌖ LẤY GPS THIẾT BỊ")
        settingsPanel.addFull(refresh)
        refresh.setOnClickListener { refreshGps() }
        addressInput = entry(model.address, "Tên địa điểm / địa chỉ")
        settingsPanel.addFull(label("Địa chỉ hiển thị")); settingsPanel.addFull(addressInput)
        val coordRow = row()
        latitudeInput = entry(model.latitude?.toString() ?: "", "Vĩ độ")
        longitudeInput = entry(model.longitude?.toString() ?: "", "Kinh độ")
        latitudeInput.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
        longitudeInput.inputType = latitudeInput.inputType
        coordRow.addWeighted(latitudeInput); coordRow.addWeighted(longitudeInput)
        settingsPanel.addFull(coordRow)
        locationMode.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                model = model.copy(manualGps = position == 0)
                latitudeInput.isEnabled = position == 0
                longitudeInput.isEnabled = position == 0
                if (position == 1) refreshGps()
                updateStamp()
            }
        }
        val saveLocation = button("ÁP DỤNG ĐỊA ĐIỂM")
        settingsPanel.addFull(saveLocation)
        saveLocation.setOnClickListener { applyLocationInputs() }
        settingsPanel.addFull(separator(), 12)
        settingsPanel.addFull(label("03   MẪU & VỊ TRÍ DẤU THỜI GIAN", 14f, gold))
        val presets = Spinner(this)
        presets.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, StampRenderer.templateNames)
        presets.setSelection(model.template)
        settingsPanel.addFull(presets)
        presets.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, pos: Int, id: Long) {
                model = model.copy(template = pos); updateStamp()
            }
        }
        settingsPanel.addFull(label("Kéo trực tiếp dấu thời gian trên khung hình, hoặc chọn cỡ chữ:"))
        val sizeBar = SeekBar(this).apply { max = 200; progress = ((model.scale - .5f) * 100).toInt().coerceIn(0, 200) }
        settingsPanel.addFull(sizeBar)
        settingsPanel.addFull(label("Độ trong suốt lớp thông tin"))
        val opacityBar = SeekBar(this).apply { max = 100; progress = (model.alpha * 100).toInt().coerceIn(20,100) }
        settingsPanel.addFull(opacityBar)
        opacityBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) { model = model.copy(alpha = (progress.coerceAtLeast(20) / 100f)); updateStamp() }
            }
        })
        sizeBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) { model = model.copy(scale = .5f + progress / 100f); updateStamp() }
            }
        })
        val tintRow = row()
        listOf("TRẮNG" to Color.WHITE, "VÀNG" to gold, "ĐỎ" to Color.RED).forEach { (caption, tint) ->
            tintRow.addWeighted(button(caption).apply { setOnClickListener { model = model.copy(textColor=tint); updateStamp() } })
        }
        settingsPanel.addFull(tintRow)
        noteInput = entry(model.note, "Ghi chú tùy chọn")
        settingsPanel.addFull(noteInput)
        settingsPanel.addFull(label("04   XUẤT VIDEO: MẶC ĐỊNH GIỮ NGUYÊN TOÀN BỘ THỜI LƯỢNG", 14f, gold), 12)
        trimToggle = CheckBox(this).apply { text = "Chỉ xuất một đoạn (tùy chọn)"; setTextColor(white) }
        settingsPanel.addFull(trimToggle)
        val trimRow = row()
        trimFrom = entry("0", "Bắt đầu (giây)")
        trimTo = entry("0", "Kết thúc (giây)")
        trimFrom.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        trimTo.inputType = trimFrom.inputType
        trimRow.addWeighted(trimFrom); trimRow.addWeighted(trimTo)
        settingsPanel.addFull(trimRow)
        settingsPanel.addFull(label("Bản gốc luôn được giữ nguyên. GPS nhập thủ công chỉ là thông tin hiển thị, không phải vị trí đã xác minh."))
        settingsPanel.addFull(label("Ứng dụng bản native alpha: vẫn cần kiểm thử APK thực trên Android.", 11f))
        updateStamp()
    }
    /** Center a fitting content rectangle inside the viewport. The stamp overlay shares its exact bounds. */
    private fun fitContentFrame() {
        if (!this::stage.isInitialized || !this::contentStage.isInitialized) return
        val aw = stage.width; val ah = stage.height
        if (aw <= 0 || ah <= 0) return
        val viewportRatio = aw.toDouble() / ah
        val cameraRatio = when (if (this::ratioSelect.isInitialized) ratioSelect.selectedItemPosition else 0) {
            1 -> 3.0 / 4.0
            2 -> viewportRatio
            3 -> 1.0
            else -> 9.0 / 16.0
        }
        val isLibrary = activeTab == "THƯ VIỆN"
        val contentRatio = if (isLibrary && mediaWidth > 0 && mediaHeight > 0)
            mediaWidth.toDouble() / mediaHeight else cameraRatio
        val fitted = FrameGeometry.fitInside(aw, ah, contentRatio)
        val existing = contentStage.layoutParams as FrameLayout.LayoutParams
        if (existing.width != fitted.width || existing.height != fitted.height) {
            contentStage.layoutParams = FrameLayout.LayoutParams(fitted.width, fitted.height, Gravity.CENTER)
        }
    }
    private fun info(message: String) { status.text = message }
    private fun applyLocationInputs(): Boolean {
        val lat = latitudeInput.text.toString().trim().toDoubleOrNull()
        val lon = longitudeInput.text.toString().trim().toDoubleOrNull()
        val valid = (lat == null && lon == null) || (lat != null && lon != null && lat in -90.0..90.0 && lon in -180.0..180.0)
        if (!valid) { info("Tọa độ phải đủ cả vĩ độ/kinh độ và nằm trong phạm vi hợp lệ"); return false }
        model = model.copy(address = addressInput.text.toString().trim(), latitude = lat, longitude = lon,
            note = noteInput.text.toString().trim())
        updateStamp(); return true
    }
    private fun updateStamp() {
        if (!this::overlay.isInitialized) return
        overlay.stamp = model
        saved.save(model)
    }
    private fun pickDateTime() {
        val cal = Calendar.getInstance().apply { timeInMillis = model.startEpochMs }
        DatePickerDialog(this, { _, year, month, day ->
            TimePickerDialog(this, { _, hour, min ->
                cal.set(year, month, day, hour, min, 0)
                model = model.copy(startEpochMs = cal.timeInMillis, customTime = true)
                dateButton.text = clockFormat.format(cal.time); customTimeCheck.isChecked = true; updateStamp()
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }
    private fun refreshGps() {
        if (locationMode.selectedItemPosition != 1) { info("Chuyển sang GPS thực tế trước khi làm mới."); return }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissions.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            return
        }
        info("Đang đọc GPS từ điện thoại…")
        location.requestCurrentLocation { loc, warning ->
            if (loc == null) { info(warning ?: "Không lấy được GPS"); return@requestCurrentLocation }
            model = model.copy(manualGps = false, latitude = loc.latitude, longitude = loc.longitude,
                gpsAccuracy = if (loc.hasAccuracy()) loc.accuracy else null)
            latitudeInput.setText("%.6f".format(Locale.US, loc.latitude))
            longitudeInput.setText("%.6f".format(Locale.US, loc.longitude))
            info("GPS thiết bị ±${loc.accuracy.toInt()} m. ${warning ?: ""}")
            updateStamp()
            location.addressFor(loc) { address -> if (address.isNotBlank()) {
                model = model.copy(address=address)
                addressInput.setText(address); updateStamp()
            } }
        }
    }
    private fun setTab(tab: String) {
        if (recording != null && tab != "VIDEO") { info("Dừng ghi hình trước khi chuyển chế độ"); return }
        activeTab = tab
        val lib = tab == "THƯ VIỆN"
        fitContentFrame()
        preview.visibility = if (lib) View.GONE else View.VISIBLE
        player.visibility = if (lib && selectedIsVideo) View.VISIBLE else View.GONE
        imagePreview.visibility = if (lib && !selectedIsVideo) View.VISIBLE else View.GONE
        timeline.visibility = if (lib && selectedIsVideo) View.VISIBLE else View.GONE
        cameraAction.visibility = if (tab == "CAMERA") View.VISIBLE else View.GONE
        recordAction.visibility = if (tab == "VIDEO") View.VISIBLE else View.GONE
        switchAction.visibility = if (!lib) View.VISIBLE else View.GONE
        exportAction.visibility = if (lib) View.VISIBLE else View.GONE
        shareAction.visibility = if (lastExport != null) View.VISIBLE else View.GONE
        if (!lib && tab in listOf("CAMERA", "VIDEO")) startCamera()
        if (tab == "MẪU" || tab == "CÀI ĐẶT") info("Chọn mẫu và tùy chỉnh ở bảng công cụ bên dưới.")
    }
    private fun startCamera() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissions.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)); return
        }
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                cameraProvider = future.get()
                val selector = if (usingFrontCamera) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                val cameraAspect = if (this::ratioSelect.isInitialized && ratioSelect.selectedItemPosition == 1)
                    AspectRatio.RATIO_4_3 else AspectRatio.RATIO_16_9
                val viewFinder = Preview.Builder().setTargetAspectRatio(cameraAspect).build().apply {
                    surfaceProvider = preview.surfaceProvider
                }
                cameraProvider?.unbindAll()
                if (activeTab == "VIDEO") {
                    val recorder = Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.FHD,
                        FallbackStrategy.lowerQualityOrHigherThan(Quality.HD))).build()
                    val videoCase = VideoCapture.withOutput(recorder)
                    videoCapture = videoCase
                    val group = UseCaseGroup.Builder().addUseCase(viewFinder).addUseCase(videoCase).apply {
                        preview.viewPort?.let { setViewPort(it) }
                    }.build()
                    cameraProvider?.bindToLifecycle(this, selector, group)
                } else {
                    val photoCase = ImageCapture.Builder().setTargetAspectRatio(cameraAspect).build()
                    imageCapture = photoCase
                    val group = UseCaseGroup.Builder().addUseCase(viewFinder).addUseCase(photoCase).apply {
                        preview.viewPort?.let { setViewPort(it) }
                    }.build()
                    cameraProvider?.bindToLifecycle(this, selector, group)
                }
            } catch (e: Exception) { info("Không mở được camera: ${e.localizedMessage}") }
        }, ContextCompat.getMainExecutor(this))
    }
    private fun takePhoto() {
        if (!applyLocationInputs()) return
        val capture = imageCapture ?: return
        val temp = File(cacheDir, "camera_${System.currentTimeMillis()}.jpg")
        capture.takePicture(ImageCapture.OutputFileOptions.Builder(temp).build(),
            ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
                override fun onError(exception: ImageCaptureException) { info("Lỗi chụp ảnh: ${exception.message}") }
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    val stamp = model.copy()
                    val clock = if (stamp.customTime) stamp.startEpochMs else System.currentTimeMillis()
                    taskRunner.execute {
                        val result = runCatching { PhotoEngine(this@MainActivity).export(Uri.fromFile(temp), stamp, clock) }
                        temp.delete()
                        runOnUiThread { result.onSuccess { lastExport = it; info("Đã lưu ảnh PNG có timestamp"); setTab("CAMERA") }
                            .onFailure { info("Không lưu được ảnh: ${it.message}") } }
                    }
                }
            })
    }
    private fun toggleRecording() {
        if (recording != null) { recording?.stop(); return }
        if (!applyLocationInputs()) return
        val capture = videoCapture ?: return
        val file = File(cacheDir, "camera_${System.currentTimeMillis()}.mp4")
        val options = FileOutputOptions.Builder(file).build()
        var request = capture.output.prepareRecording(this, options)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            request = request.withAudioEnabled()
        }
        val startAt = if (model.customTime) model.startEpochMs else System.currentTimeMillis()
        recordStartElapsedMs = android.os.SystemClock.elapsedRealtime()
        recording = request.start(ContextCompat.getMainExecutor(this)) { event ->
            when (event) {
                is VideoRecordEvent.Start -> { recordAction.text = "■ DỪNG QUAY"; info("Đang quay video…") }
                is VideoRecordEvent.Finalize -> {
                    recording = null; recordAction.text = "● QUAY VIDEO"
                    if (event.hasError()) { info("Lỗi quay: ${event.error}") }
                    else {
                        val oldCustom = model.customTime
                        model = model.copy(customTime = true, startEpochMs = startAt)
                        loadMedia(Uri.fromFile(file))
                        info("Đã quay xong. Nhấn LƯU ẢNH / VIDEO để chèn timestamp và xuất MP4.")
                        if (!oldCustom) updateStamp()
                    }
                }
            }
        }
    }
    private fun loadMedia(uri: Uri) {
        selectedMedia = uri
        val mime = contentResolver.getType(uri) ?: ""
        selectedIsVideo = mime.startsWith("video/") || uri.toString().endsWith(".mp4", true)
        mediaDurationMs = if (selectedIsVideo) runCatching { MediaStoreUtils.durationMs(this, uri) }.getOrDefault(0L) else 0L
        if (selectedIsVideo) {
            val dims = runCatching { MediaStoreUtils.videoDisplaySize(this, uri) }.getOrNull()
            mediaWidth = dims?.first ?: 9
            mediaHeight = dims?.second ?: 16
        } else { mediaWidth = 0; mediaHeight = 0 }
        setTab("THƯ VIỆN")
        if (selectedIsVideo) {
            player.setVideoURI(uri)
            player.setOnPreparedListener { p ->
                p.isLooping = false; p.seekTo(0)
                info("Video đã tải: ${mediaDurationMs / 1000}s. Giữ đúng tỷ lệ nguồn và xuất đầy đủ.")
            }
            trimTo.setText((mediaDurationMs / 1000.0).toString())
        } else {
            taskRunner.execute {
                runCatching { android.graphics.ImageDecoder.decodeBitmap(
                    android.graphics.ImageDecoder.createSource(contentResolver, uri)) }
                    .onSuccess { bmp -> runOnUiThread {
                        mediaWidth = bmp.width; mediaHeight = bmp.height
                        fitContentFrame()
                        imagePreview.setImageBitmap(bmp)
                        info("Ảnh đã tải. Khung xem trước tự khớp ${bmp.width}×${bmp.height}.")
                    } }
                    .onFailure { runOnUiThread { info("Không mở được ảnh: ${it.message}") } }
            }
        }
    }
    private fun exportSelected() {
        if (!applyLocationInputs()) return
        val input = selectedMedia ?: run { info("Chưa chọn ảnh hoặc video"); return }
        val snapshot = model.copy()
        if (!selectedIsVideo) {
            taskRunner.execute {
                val timestamp = if (snapshot.customTime) snapshot.startEpochMs else System.currentTimeMillis()
                val result = runCatching { PhotoEngine(this).export(input, snapshot, timestamp) }
                runOnUiThread { result.onSuccess { lastExport = it; info("Đã lưu PNG vào thư viện ảnh"); shareAction.visibility = View.VISIBLE }
                    .onFailure { info("Xuất ảnh lỗi: ${it.message}") } }
            }
            return
        }
        val trim = trimToggle.isChecked
        val from = ((trimFrom.text.toString().toDoubleOrNull() ?: 0.0) * 1000).toLong()
        val to = ((trimTo.text.toString().toDoubleOrNull() ?: 0.0) * 1000).toLong()
        exportAction.isEnabled = false
        val timestampConfig = if (snapshot.customTime) snapshot else snapshot.copy(customTime = true,
            startEpochMs = System.currentTimeMillis())
        exporter.export(input, timestampConfig, trim, from, to, { message -> info(message) }) { result ->
            exportAction.isEnabled = true
            result.onSuccess { lastExport = it; shareAction.visibility = View.VISIBLE; info("Đã lưu MP4 trong thư viện Movies") }
                .onFailure { info("Xuất video lỗi: ${it.localizedMessage}") }
        }
    }
    private fun shareExport() {
        val uri = lastExport ?: return
        val mime = if (uri.toString().contains("video")) "video/mp4" else "*/*"
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime; putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Chia sẻ kết quả"))
    }
    private fun uiClock() {
        val ticker = object : Runnable {
            override fun run() {
                if (selectedIsVideo && activeTab == "THƯ VIỆN") {
                    val current = player.currentPosition.toLong().coerceAtLeast(0L)
                    if (mediaDurationMs > 0) timeline.progress = (current * 1000 / mediaDurationMs).toInt()
                    counter.text = "${current / 1000}s / ${mediaDurationMs / 1000}s"
                    overlay.currentTimeMs = if (model.customTime)
                        TimeEngine.atPresentationUs(model.startEpochMs, current * 1000)
                    else System.currentTimeMillis()
                } else overlay.currentTimeMs = if (recording != null) {
                    if (model.customTime) model.startEpochMs + (android.os.SystemClock.elapsedRealtime() - recordStartElapsedMs)
                    else System.currentTimeMillis()
                } else if (model.customTime) model.startEpochMs else System.currentTimeMillis()
                handler.postDelayed(this, 200)
            }
        }
        handler.post(ticker)
    }
}
