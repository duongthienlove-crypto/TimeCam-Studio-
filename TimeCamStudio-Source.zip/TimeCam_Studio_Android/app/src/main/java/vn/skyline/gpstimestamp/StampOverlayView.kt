package vn.skyline.gpstimestamp

import android.content.Context
import android.graphics.Canvas
import android.view.MotionEvent
import android.view.View

/** Editable preview, directly movable by one finger. Never persists the raw source. */
class StampOverlayView(context: Context): View(context) {
    var stamp: StampModel = StampModel()
        set(value) { field = value; invalidate() }
    var currentTimeMs: Long = System.currentTimeMillis()
        set(value) { field = value; invalidate() }
    var dragListener: ((Float, Float) -> Unit)? = null
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        StampRenderer.draw(canvas, width, height, stamp, currentTimeMs)
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when(event.actionMasked) {
            MotionEvent.ACTION_DOWN -> return true
            MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> {
                dragListener?.invoke(event.x / width.coerceAtLeast(1), event.y / height.coerceAtLeast(1))
                return true
            }
        }
        return super.onTouchEvent(event)
    }
}
