package vn.skyline.timecam;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Android shell for offline TimeCam Studio. Media manipulation is implemented
 * in the bundled HTML using Canvas + MediaRecorder.
 * Camera, microphone, GPS and saved files remain on the user's device.
 */
public class MainActivity extends Activity {
    private static final int REQUEST_MEDIA_PERMISSION = 601;
    private static final int REQUEST_GEO_PERMISSION = 602;
    private static final int REQUEST_FILE_PICKER = 603;
    private static final String APP_URL = "https://appassets.androidplatform.net/assets/index.html";
    private static final String APP_PREFIX = "https://appassets.androidplatform.net/assets/";

    private WebView webView;
    private PermissionRequest pendingPermissionRequest;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;
    private ValueCallback<Uri[]> fileCallback;
    private final Map<String, ExportSession> exportSessions = new ConcurrentHashMap<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(14, 17, 22));
        getWindow().setNavigationBarColor(Color.rgb(14, 17, 22));
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(14, 17, 22));
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setGeolocationEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);

        webView.addJavascriptInterface(new NativeBridge(), "NativeBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String url = uri.toString();
                if (url.startsWith(APP_PREFIX)) {
                    String asset = url.substring(APP_PREFIX.length());
                    if (asset.isEmpty()) asset = "index.html";
                    if (asset.contains("..") || asset.contains("\\") || asset.contains("?")) {
                        return new WebResourceResponse("text/plain", "UTF-8", null);
                    }
                    try {
                        InputStream input = getAssets().open(asset);
                        String mime = asset.endsWith(".html") ? "text/html"
                            : asset.endsWith(".js") ? "application/javascript"
                            : asset.endsWith(".css") ? "text/css"
                            : asset.endsWith(".svg") ? "image/svg+xml" : "application/octet-stream";
                        return new WebResourceResponse(mime, "UTF-8", input);
                    } catch (IOException ignored) {
                        return new WebResourceResponse("text/plain", "UTF-8", null);
                    }
                }
                return new WebResourceResponse("text/plain", "UTF-8", null);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !request.getUrl().toString().startsWith(APP_PREFIX);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    if (!request.getOrigin().toString().startsWith("https://appassets.androidplatform.net")) {
                        request.deny(); return;
                    }
                    pendingPermissionRequest = request;
                    if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
                        || checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[] {Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}, REQUEST_MEDIA_PERMISSION);
                    } else grantMediaPermissions();
                });
            }
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (!origin.startsWith("https://appassets.androidplatform.net")) {
                    callback.invoke(origin, false, false); return;
                }
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, false);
                } else {
                    pendingGeoCallback = callback;
                    pendingGeoOrigin = origin;
                    requestPermissions(new String[]{ Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION }, REQUEST_GEO_PERMISSION);
                }
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    intent.setType("*/*");
                    intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] { "image/*", "video/*" });
                    startActivityForResult(intent, REQUEST_FILE_PICKER);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
            }
        });
        webView.loadUrl(APP_URL);
    }

    private void grantMediaPermissions() {
        PermissionRequest req = pendingPermissionRequest;
        pendingPermissionRequest = null;
        if (req == null) return;
        java.util.ArrayList<String> ok = new java.util.ArrayList<>();
        for (String resource : req.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)
                && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
                ok.add(resource);
            else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                ok.add(resource);
        }
        if (ok.isEmpty()) req.deny(); else req.grant(ok.toArray(new String[0]));
    }

    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(code, permissions, grants);
        if (code == REQUEST_MEDIA_PERMISSION) grantMediaPermissions();
        else if (code == REQUEST_GEO_PERMISSION && pendingGeoCallback != null) {
            boolean granted = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
            pendingGeoCallback.invoke(pendingGeoOrigin, granted, false);
            pendingGeoCallback = null;
        }
    }

    @Override protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == REQUEST_FILE_PICKER && fileCallback != null) {
            Uri[] resultUris = WebChromeClient.FileChooserParams.parseResult(result, data);
            fileCallback.onReceiveValue(resultUris);
            fileCallback = null;
        }
    }

    private static class ExportSession {
        final Uri uri;
        final OutputStream output;
        ExportSession(Uri uri, OutputStream output) { this.uri=uri;this.output=output; }
    }

    public class NativeBridge {
        @JavascriptInterface public String beginExport(String token, String name, String mime) {
            try {
                if (!token.matches("[A-Za-z0-9_-]{1,80}")) return "Bad export token";
                if (exportSessions.containsKey(token)) return "Duplicate export token";
                name = name.replaceAll("[^A-Za-z0-9._-]", "_");
                if (!name.matches("[A-Za-z0-9][A-Za-z0-9._-]{0,120}\\.(png|jpg|jpeg|webm|txt)")) return "Invalid file name";
                if (!mime.equals("image/png") && !mime.equals("image/jpeg") && !mime.startsWith("video/webm")) return "Invalid media type";
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/TimeCam Studio");
                values.put(MediaStore.MediaColumns.IS_PENDING, 1);
                ContentResolver resolver = getContentResolver();
                Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) return "Cannot create MediaStore entry";
                OutputStream os = resolver.openOutputStream(uri, "w");
                if (os == null) { resolver.delete(uri,null,null); return "Cannot write file"; }
                exportSessions.put(token,new ExportSession(uri,os));
                return "OK";
            } catch (Exception e) { return "Save failure: "+e.getMessage(); }
        }
        @JavascriptInterface public String appendExportChunk(String token, String chunk) {
            ExportSession es = exportSessions.get(token);
            if (es == null) return "No export session";
            try {es.output.write(Base64.decode(chunk, Base64.DEFAULT)); return "OK";}
            catch(Exception e){return "Write failure: "+e.getMessage();}
        }
        @JavascriptInterface public String finishExport(String token) {
            ExportSession es=exportSessions.remove(token);
            if(es==null) return "No export session";
            try {
                es.output.close();
                ContentValues values=new ContentValues();
                values.put(MediaStore.MediaColumns.IS_PENDING,0);
                getContentResolver().update(es.uri, values,null,null);
                runOnUiThread(()->Toast.makeText(MainActivity.this,"Đã lưu vào Download/TimeCam Studio",Toast.LENGTH_SHORT).show());
                return "OK";
            }catch(Exception e){return "Finish failure: "+e.getMessage();}
        }
        @JavascriptInterface public void failExport(String token) {
            ExportSession es=exportSessions.remove(token);
            if(es!=null){try{es.output.close();}catch(IOException ignored){}getContentResolver().delete(es.uri,null,null);}
        }
    }

    @Override public void onBackPressed() {
        if(webView.canGoBack())webView.goBack();else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        for(ExportSession s:exportSessions.values()) {try{s.output.close();}catch(IOException ignored){}}
        exportSessions.clear();
        if(webView!=null){webView.destroy();webView=null;}
        super.onDestroy();
    }
}
