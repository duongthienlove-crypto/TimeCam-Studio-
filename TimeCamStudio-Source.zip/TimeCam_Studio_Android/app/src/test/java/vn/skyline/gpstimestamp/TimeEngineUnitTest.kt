package vn.skyline.gpstimestamp

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant

class TimeEngineUnitTest {
    private val base = Instant.parse("2026-10-13T01:30:00Z").toEpochMilli()
    @Test fun beginning() = assertEquals(base, TimeEngine.atPresentationUs(base, 0))
    @Test fun fifteenSeconds() = assertEquals(base + 15_000, TimeEngine.atPresentationUs(base, 15_000_000))
    @Test fun fiveMinutes() = assertEquals(base + 300_000, TimeEngine.atPresentationUs(base, 300_000_000))
    @Test fun tenMinutes() = assertEquals(base + 600_000, TimeEngine.atPresentationUs(base, 600_000_000))
    @Test fun twoMinutesSevenSeconds() = assertEquals(base + 127_000, TimeEngine.atPresentationUs(base, 127_000_000))
    @Test fun clippingUsesSourceOffset() = assertEquals(base + 12_500, TimeEngine.atClippedPresentationUs(base, 10_000, 2_500_000))
    @Test fun fullVideoWhenTrimDisabled() = assertEquals(0L to 127_000L, TimeEngine.validateRange(127_000, 10_000, 20_000, false))
    @Test fun trimSelectsRange() = assertEquals(55_000L to 60_000L, TimeEngine.validateRange(127_000, 55_000, 60_000, true))
    @Test fun invalidRangeFails() = assertTrue(runCatching { TimeEngine.validateRange(1_000, 900, 100, true) }.isFailure)
}
