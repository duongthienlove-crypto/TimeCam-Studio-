package vn.skyline.gpstimestamp

fun main() {
    fun checkRatio(w: Int, h: Int, ratio: Double) {
        val size = FrameGeometry.fitInside(w, h, ratio)
        check(size.width in 1..w && size.height in 1..h)
        check(kotlin.math.abs(size.width.toDouble()/size.height - ratio) < 0.025) {
            "Actual ${size.width}x${size.height} differs from $ratio"
        }
    }
    checkRatio(400, 800, 9.0/16)
    checkRatio(400, 800, 3.0/4)
    checkRatio(400, 800, 1.0)
    checkRatio(400, 800, 16.0/9)
    checkRatio(1080, 1920, 9.0/16)
    checkRatio(1000, 800, 3.0/4)
    val x = FrameGeometry.fitInside(480, 1000, 0.48)
    check(x.width == 480 && x.height == 1000)
    println("7 frame aspect checks OK")
}
