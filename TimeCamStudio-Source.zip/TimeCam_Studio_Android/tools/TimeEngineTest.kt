import vn.skyline.gpstimestamp.TimeEngine
import java.time.Instant

fun main() {
    val start = Instant.parse("2026-10-13T01:30:00Z").toEpochMilli()
    fun checkEq(expected: Long, actual: Long) = check(expected == actual) { "Expected $expected but got $actual" }
    checkEq(start, TimeEngine.atPresentationUs(start, 0))
    checkEq(start + 15_000, TimeEngine.atPresentationUs(start, 15_000_000))
    checkEq(start + 300_000, TimeEngine.atPresentationUs(start, 300_000_000))
    checkEq(start + 600_000, TimeEngine.atPresentationUs(start, 600_000_000))
    checkEq(start + 127_000, TimeEngine.atPresentationUs(start, 127_000_000))
    checkEq(start + 12_500, TimeEngine.atClippedPresentationUs(start, 10_000, 2_500_000))
    check(TimeEngine.validateRange(127_000, 55_000, 60_000, false) == 0L to 127_000L)
    check(TimeEngine.validateRange(127_000, 55_000, 60_000, true) == 55_000L to 60_000L)
    check(runCatching { TimeEngine.validateRange(1000L, 900L, 100L, true) }.isFailure)
    println("PASS 9 TimeEngine checks: full video, seeking, 2m07, clipping, invalid trim")
}
